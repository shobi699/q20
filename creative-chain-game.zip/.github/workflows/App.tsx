import React from 'react';
import { HashRouter, Routes, Route, Link, Outlet, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '../hooks/useAuth';
import HomePage from '../pages/HomePage';
import PlayPage from '../pages/PlayPage';
import AdminPage from '../pages/admin/AdminPage';

const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-grow container mx-auto p-4">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/play" element={<ProtectedRoute><PlayPage /></ProtectedRoute>} />
              <Route path="/admin/*" element={<AdminRoute><AdminPage /></AdminRoute>} />
            </Routes>
          </main>
        </div>
      </HashRouter>
    </AuthProvider>
  );
};

const Header: React.FC = () => {
  const { user, profile, signOut } = useAuth();
  const isAnonymous = user?.is_anonymous;

  const handleGuestLoginClick = async () => {
    await signOut();
  }

  return (
    <header className="bg-surface shadow-md">
      <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/" className="text-xl font-bold text-primary">بازی زنجیرهٔ خلاقیت</Link>
        <div className="flex items-center gap-4">
          {user && <Link to="/play" className="hover:text-secondary">بازی</Link>}
          {profile?.is_admin && <Link to="/admin" className="hover:text-secondary">پنل مدیریت</Link>}
          {user ? (
            isAnonymous ? (
              <button onClick={handleGuestLoginClick} className="hover:text-secondary">ورود / ثبت‌نام</button>
            ) : (
              <button onClick={signOut} className="bg-error text-on-primary px-3 py-1 rounded">خروج</button>
            )
          ) : (
            <Link to="/" className="hover:text-secondary">ورود</Link>
          )}
        </div>
      </nav>
    </header>
  );
};

// Fix: Changed React.ReactElement to JSX.Element to resolve namespace error.
const ProtectedRoute = ({ children }: { children: JSX.Element }) => {
  const { user, loading } = useAuth();
  if (loading) return <div>Loading...</div>;
  if (!user) return <Navigate to="/" />;
  return children;
};

// Fix: Changed React.ReactElement to JSX.Element to resolve namespace error.
const AdminRoute = ({ children }: { children: JSX.Element }) => {
    const { profile, loading } = useAuth();
    if (loading) return <div>Loading...</div>;
    if (!profile?.is_admin) {
        return (
            <div className="text-center p-8">
                <h1 className="text-3xl text-error font-bold">403 - Forbidden</h1>
                <p className="mt-4">شما دسترسی لازم برای مشاهده این صفحه را ندارید.</p>
            </div>
        )
    };
    return children;
};


export default App;
