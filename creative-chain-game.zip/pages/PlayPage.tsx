import React, { useState, useEffect, useCallback } from 'react';
import { Game, Node } from '../types';
import { createNewGame, submitAnswer } from '../services/api';
import { supabase } from '../lib/supabase/client';

const PlayPage: React.FC = () => {
  const [game, setGame] = useState<Game | null>(null);
  const [currentTarget, setCurrentTarget] = useState<Node | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [answer, setAnswer] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastResult, setLastResult] = useState<any>(null);
  const [startTime, setStartTime] = useState(Date.now());

  const fetchNodeTitle = useCallback(async (nodeId: number) => {
    // Fix: Included `tags` in the select query to match the `Node` type, which was causing type errors on `setCurrentTarget`.
    const { data, error } = await supabase.from('nodes').select('id, title, slug, tags').eq('id', nodeId).single();
    if (error) {
      console.error("Error fetching node", error);
      setError("خطا در یافتن هدف بعدی.");
      return null;
    }
    return data;
  }, []);

  const handleNewGame = useCallback(async () => {
    setLoading(true);
    setError(null);
    setLastResult(null);
    try {
      const newGame: Game = await createNewGame();
      setGame(newGame);
      const targetNode = await fetchNodeTitle(newGame.current_target_node_id);
      setCurrentTarget(targetNode);
      setStartTime(Date.now());
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [fetchNodeTitle]);

  useEffect(() => {
    handleNewGame();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!game || !currentTarget || isSubmitting || !answer.trim()) return;

    setIsSubmitting(true);
    setError(null);
    const timeMs = Date.now() - startTime;

    try {
      const result = await submitAnswer({
        game_id: game.id,
        target_id: currentTarget.id,
        answer_text: answer,
        step: game.current_step,
        time_ms: timeMs,
      });
      
      setLastResult(result);
      setAnswer('');

      if (result.valid) {
        setGame(prev => prev ? { ...prev, current_score: prev.current_score + result.stepScore, current_step: prev.current_step + 1 } : null);
        const nextNode = await fetchNodeTitle(result.nextTargetId);
        setCurrentTarget(nextNode);
        setStartTime(Date.now());
      } else {
        setGame(prev => prev ? { ...prev, is_active: false } : null);
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return <div className="text-center p-8">در حال آماده‌سازی بازی...</div>;
  if (error) return <div className="text-center p-8 text-error">خطا: {error}</div>;

  return (
    <div className="w-full max-w-2xl mx-auto p-6 bg-surface rounded-lg shadow-xl">
      {game && game.is_active ? (
        <>
          <div className="flex justify-between items-baseline mb-4">
            <h2 className="text-xl">مرحله: <span className="font-bold text-secondary">{game.current_step}</span></h2>
            <h2 className="text-xl">امتیاز کل: <span className="font-bold text-primary">{game.current_score}</span></h2>
          </div>
          <div className="text-center my-8">
            <p className="text-lg mb-2 text-on-surface/80">«{currentTarget?.title}» را با چه چیزی نابود می‌کنی؟</p>
          </div>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="پاسخ کوتاه (۱-۲ واژه)"
              className="w-full bg-background border border-on-surface/20 rounded-md p-3 text-center text-lg focus:ring-2 focus:ring-primary focus:outline-none"
              disabled={isSubmitting}
            />
            <button
              type="submit"
              disabled={isSubmitting || !answer.trim()}
              className="w-full mt-4 bg-primary text-on-primary font-bold py-3 rounded-md hover:bg-primary-variant disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
            >
              {isSubmitting ? 'در حال بررسی...' : 'ثبت'}
            </button>
          </form>
        </>
      ) : (
        <div className="text-center">
            <h2 className="text-3xl font-bold text-error">بازی تمام شد!</h2>
            <p className="mt-4 text-xl">امتیاز نهایی شما: <span className="font-bold text-primary">{game?.current_score}</span></p>
            <button onClick={handleNewGame} className="mt-8 bg-secondary text-on-secondary font-bold py-3 px-6 rounded-md hover:opacity-90 transition-opacity">
                بازی جدید
            </button>
        </div>
      )}
      
      {lastResult && (
        <div className={`mt-6 p-4 rounded-md text-center ${lastResult.valid ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
          {lastResult.valid ? (
            <div>
              <p className="font-bold text-lg">✅ پاسخ صحیح!</p>
              <p>امتیاز این مرحله: <span className="font-mono">{lastResult.stepScore}</span></p>
              <p>کمیابی: <span className="font-mono">{lastResult.rarity.toFixed(2)}</span></p>
              {lastResult.is_rare && <p className="mt-2 text-primary animate-pulse">✨ تو خاصی! ✨</p>}
            </div>
          ) : (
            <p className="font-bold text-lg">❌ پاسخ نامعتبر بود.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default PlayPage;