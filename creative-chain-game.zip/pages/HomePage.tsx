
import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import AuthForm from '../components/AuthForm';
import { useAuth } from '../hooks/useAuth';

const HomePage: React.FC = () => {
  const { user, loading, signInAnonymously } = useAuth();
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [isGuestLoading, setIsGuestLoading] = useState(false);

  const handleGuestPlay = async () => {
    setIsGuestLoading(true);
    try {
      await signInAnonymously();
      // The redirect will happen automatically when `user` state updates
    } catch (error) {
      console.error("Failed to sign in anonymously", error);
      // You could show an error message to the user here
      setIsGuestLoading(false);
    }
  };


  if (loading) {
    return <div className="text-center p-8">در حال بارگذاری...</div>;
  }

  if (user) {
    return <Navigate to="/play" />;
  }

  return (
    <div className="flex flex-col items-center justify-center pt-10">
      <div className="w-full max-w-md p-8 space-y-6 bg-surface rounded-lg shadow-lg text-center">
        <h1 className="text-4xl font-bold text-primary">به زنجیرهٔ خلاقیت خوش آمدید!</h1>
        <p className="text-on-surface/80">
          یک کلمه به شما داده می‌شود. با یک کلمهٔ مرتبط آن را نابود کنید و زنجیره را ادامه دهید. خلاق باشید و امتیاز کسب کنید!
        </p>

        {!showAuthForm ? (
          <div className="space-y-4 pt-4">
            <button
              onClick={handleGuestPlay}
              disabled={isGuestLoading}
              className="w-full py-3 px-4 bg-secondary text-on-secondary font-bold rounded-md hover:opacity-90 disabled:bg-gray-500 transition-all"
            >
              {isGuestLoading ? 'در حال ورود...' : 'بازی به عنوان مهمان'}
            </button>
            <button
              onClick={() => setShowAuthForm(true)}
              className="w-full py-2 text-primary hover:underline"
            >
              ورود یا ثبت‌نام با ایمیل
            </button>
          </div>
        ) : (
          <>
            <AuthForm />
            <button 
              onClick={() => setShowAuthForm(false)}
              className="text-sm text-on-surface/60 hover:underline mt-4"
            >
              بازگشت
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default HomePage;