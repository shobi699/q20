
import React from 'react';
import { Routes, Route, NavLink } from 'react-router-dom';
import AdminDashboard from '../../admin/AdminDashboard';
import AdminGraph from '../../admin/AdminGraph';
import AdminLogs from '../../admin/AdminLogs';

const AdminPage: React.FC = () => {
    return (
        <div className="flex">
            <aside className="w-64 bg-surface p-4 rounded-lg me-4">
                <h2 className="text-xl font-bold mb-4 text-primary">پنل مدیریت</h2>
                <nav className="flex flex-col space-y-2">
                    <AdminNavLink to="/admin">داشبورد</AdminNavLink>
                    <AdminNavLink to="/admin/graph">گراف دانش</AdminNavLink>
                    <AdminNavLink to="/admin/logs">لاگ‌ها</AdminNavLink>
                    {/* Add other admin links here */}
                </nav>
            </aside>
            <div className="flex-1 bg-surface p-6 rounded-lg">
                <Routes>
                    <Route path="/" element={<AdminDashboard />} />
                    <Route path="/graph" element={<AdminGraph />} />
                    <Route path="/logs" element={<AdminLogs />} />
                </Routes>
            </div>
        </div>
    );
};

interface AdminNavLinkProps {
    to: string;
    children: React.ReactNode;
}
const AdminNavLink: React.FC<AdminNavLinkProps> = ({ to, children }) => {
    const activeClass = "bg-primary text-on-primary";
    const inactiveClass = "hover:bg-primary/20";
    return (
        <NavLink
            to={to}
            end={to === "/admin"}
            className={({ isActive }) => 
                `block px-4 py-2 rounded-md transition-colors ${isActive ? activeClass : inactiveClass}`
            }
        >
            {children}
        </NavLink>
    )
}


export default AdminPage;