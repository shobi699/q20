import React, { useState } from 'react';
import { supabase } from '../lib/supabase/client';

const AuthForm: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        // This is where the user will be redirected after clicking the magic link.
        emailRedirectTo: window.location.origin,
      },
    });

    if (error) {
      setError(error.message);
    } else {
      setMessage('ایمیل تایید برای شما ارسال شد. لطفا صندوق ورودی خود را چک کنید.');
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleLogin} className="space-y-4">
      {message && <p className="text-center text-green-400">{message}</p>}
      {error && <p className="text-center text-error">{error}</p>}
      <div>
        <label htmlFor="email" className="block text-sm font-medium text-on-surface/80">ایمیل</label>
        <input
          id="email"
          className="w-full mt-1 p-2 bg-background border border-on-surface/20 rounded-md focus:ring-primary focus:border-primary"
          type="email"
          placeholder="your@email.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>
      <div>
        <button
          type="submit"
          disabled={loading}
          className="w-full py-2 px-4 bg-primary text-on-primary font-semibold rounded-md hover:bg-primary-variant disabled:bg-gray-500"
        >
          {loading ? 'در حال ارسال...' : 'ارسال لینک ورود'}
        </button>
      </div>
    </form>
  );
};

export default AuthForm;