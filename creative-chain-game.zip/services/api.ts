import { supabase } from '../lib/supabase/client';

// The Supabase URL is hardcoded here to match the client configuration.
const supabaseUrl = 'https://rjaydfbfhobmewxabdqi.supabase.co';

const getFunctionUrl = (name: string) => {
    return `${supabaseUrl}/functions/v1/${name}`;
}

const getHeaders = async () => {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error || !session) {
        throw new Error('User not authenticated');
    }
    return {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`,
    };
}

// Emulates POST /api/game/new
export const createNewGame = async () => {
    const response = await fetch(getFunctionUrl('game-new'), {
        method: 'POST',
        headers: await getHeaders(),
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create new game');
    }
    return response.json();
}

// Emulates POST /api/play/answer
export const submitAnswer = async (payload: {
    game_id: string;
    target_id: number;
    answer_text: string;
    step: number;
    time_ms: number;
}) => {
    const response = await fetch(getFunctionUrl('play-answer'), {
        method: 'POST',
        headers: await getHeaders(),
        body: JSON.stringify(payload),
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to submit answer');
    }
    return response.json();
}

// Admin function calls
export const adminCreateGraphNode = async (payload: { title: string; slug: string; tags: string[] }) => {
    const response = await fetch(getFunctionUrl('admin-graph'), {
        method: 'POST',
        headers: await getHeaders(),
        body: JSON.stringify({ action: 'create_node', payload }),
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create node');
    }
    return response.json();
}
